#include <cassert>
#include <cstdlib>
#include <gecode/int.hh>
#include <gecode/minimodel.hh>
#include <gecode/search.hh>
#include <fstream>
#include <vector>

using namespace std;
using namespace Gecode;

class Box : public Space {

  private:
    int w;
    vector<pair<int,int>> boxes;

  protected:
    IntVar length;

    IntVarArray x_top;
    IntVarArray y_top;

    IntVarArray x_bottom;
    IntVarArray y_bottom;

  public:

    int value_aux(IntVar x, int i) const {
      if(i == 0) return x.min();

      int dim = max(boxes[i-1].first, boxes[i-1].second);
      if (dim > w)
        dim = min(boxes[i-1].first, boxes[i-1].second);

      int x_top_ant = x_top[i-1].val() + dim;

      int val = x.min();
      for (IntVarValues v(x); v( ) ; ++v) {
        if(v.val() >= x_top_ant) {
           val = v.val();
           break;
        }
      }
      return val;
    }

    static int value(const Space& home, IntVar x, int i) {
      return static_cast<const Box&>(home).value_aux(x,i);
    }

    static void commit(Space& home, unsigned int a, IntVar x, int i, int n) {
      if (a == 0) rel(home, x, IRT_EQ, n);
      else        rel(home, x, IRT_NQ, n);
    }

    Box(int _w, int _l, const vector<pair<int,int> >& _boxes) :
      w(_w), boxes(_boxes), length(*this, 0, _l),

      x_top(*this   , _boxes.size(), 0, _w-1),
      x_bottom(*this, _boxes.size(), 0, _w-1),
      y_top(*this   , _boxes.size(), 0,   _l),
      y_bottom(*this, _boxes.size(), 0,   _l)
    {
      for(int i = 0; i < boxes.size(); i++){

        // length constraint
        rel(*this, max(y_bottom)+1 == length);

        int width = boxes[i].first;
        int height = boxes[i].second;
        int dims[2] = {width, height};

        IntSet dim(dims, 2);
        IntVar v_width(*this, dim);
        IntVar v_height(*this, dim);

        // Required to enforce (w*h, h*w) combinations
        if(width != height) rel(*this, v_width != v_height);

        // margin constraint
        rel(*this, x_top[i] <= w-v_width);

        // bounding box constraint
        rel(*this,(x_bottom[i] == x_top[i]+v_width-1));
        rel(*this,(y_bottom[i] == y_top[i]+v_height-1));

        // overlapping constraint
        for(int j = i+1; j < boxes.size(); j++) {
          rel(*this
             ,  (x_top[j] > x_bottom[i])
             || (x_bottom[j] < x_top[i])
             || (y_top[j] > y_bottom[i])
             || (y_bottom[j] < y_top[i])
             );
        }

        // Symmetry
        if(i == 0) rel(*this, x_top[0] <= 1/2*(w - v_width));
      }

      // Explore horizontal solutions first.
      branch(*this, x_top, INT_VAR_NONE(), INT_VAL(&value, &commit));
      // Then, explore the vertical solutions then.
      branch(*this, y_top   , INT_VAR_NONE(), INT_VAL_MIN());
      branch(*this, y_bottom, INT_VAR_NONE(), INT_VAL_MIN());
    }

    Box(Box& b) : Space(b) {
      length.update(*this, b.length);

      x_top.update(*this,b.x_top);
      y_top.update(*this,b.y_top);
      x_bottom.update(*this,b.x_bottom);
      y_bottom.update(*this,b.y_bottom);

      w = b.w;
      boxes = b.boxes;
    }

    virtual Space* copy() {
      return new Box(*this);
    }

    void print(void) const {
      cout << length.val() << endl;
      for(int i = 0; i < x_top.size(); ++i) {
        cout << x_top[i].val() << " " << y_top[i].val()
             << "   "
             << x_bottom[i].val() << " " << y_bottom[i].val()
             << endl;
      }
    }

    // objective function
    virtual void constrain(const Space& s) {
      const Box& b = static_cast<const Box&>(s);
      rel(*this, length < b.length);
    }
};

bool cmp(const pair<int,int>& b1, const pair<int,int>& b2) {
  return (b1.first * b1.second) > (b2.first * b2.second);
}

int main(int argc, char* argv[]) {
  try {
    if (argc != 1) return -1;

    int w, n;
    int l = 0;
    cin >> w >> n;
    cout << w << " " << n << endl;
    vector<pair<int,int>> boxes(n);
    int k = 0;
    while (k < n) {
      int m, width, height;
      cin >> m >> width >> height;
      cout << m << "   " << width << " " << height << endl;
      for (int i = 0; i < m; ++i) {
        boxes[k+i] = pair<int,int>(width,height);
        l += max(width,height);
      }
      k += m;
    }

    // First-fail Principle: try placing the biggest bozxes first.
    sort(boxes.begin(), boxes.end(), cmp);

    Box* mod = new Box(w,l,boxes);
    BAB<Box> e(mod);
    delete mod;

    Box* sant = e.next();
    Box* s    = e.next();
    while (s != NULL) {
      delete sant;
      sant = s;
      s = e.next();
    }
    sant->print();
    delete sant;
  }
  catch (Exception e) {
    cerr << "Gecode exception: " << e.what() << endl;
    return 1;
  }
  return 0;
}
